SUMAN AI — ANDROID-ONLY CLOUD APK BUILD

WHAT THIS STARTER DOES
- Android app with a JARVIS-inspired dark interface.
- Voice recognition using the Android speech recognition service.
- Text commands and spoken replies.
- Basic explicit commands: open Android Settings, open Camera, open WhatsApp (if installed).
- No background listening; tap the microphone to speak.

IMPORTANT LIMITS
This is the first starter build, not the finished full AI assistant. It does not yet connect to an AI model, access all apps, send messages, make calls, manage files, or run arbitrary actions. Those require later implementation, permissions, secure backend/API configuration, and confirmation flows. Do not put private API keys in Android source code or GitHub.

BUILD FROM ANDROID PHONE ONLY
1. Download and extract SumanAI-Android.zip on your Android phone (Files app or ZArchiver).
2. Open https://github.com in Chrome and sign in or create a GitHub account.
3. Tap +, choose New repository. Name it SumanAI-Android. Choose Public or Private, then Create repository.
4. In the new repository choose Add file > Upload files. Upload the CONTENTS of the extracted SumanAI-Android folder, including the hidden .github/workflows/build-apk.yml file. If your phone's picker hides .github, use GitHub's web editor to create this exact path: .github/workflows/build-apk.yml and paste the workflow content from the ZIP.
5. Commit the files to the main branch.
6. Open the repository's Actions tab. Select Build Suman AI APK. Tap Run workflow > Run workflow.
7. Wait for the run to finish with a green check mark. Open the completed run and find Artifacts. Download SumanAI-debug-apk.
8. Extract the downloaded artifact ZIP. Tap app-debug.apk. If Android asks, allow Chrome or Files to install unknown apps, then install.
9. Open Suman AI and grant microphone permission when you tap Talk.

TROUBLESHOOTING
- If Actions is missing, open repository Settings > Actions > General and enable Actions.
- If build fails, open the failed run, expand the red step, and share the error text or screenshot.
- Do not share GitHub passwords, access tokens, or API keys in chat.
