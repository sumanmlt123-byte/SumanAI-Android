package com.sumanai.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 101;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private TextView conversation, status;
    private EditText input;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(6,17,31));
        tts = new TextToSpeech(this, result -> { if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("en", "IN")); });
        buildUi();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); return v;
    }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22,24,22,18); root.setBackgroundColor(Color.rgb(6,17,31));
        TextView title = text("SUMAN AI", 28, Color.rgb(85,214,255)); title.setTypeface(null, Typeface.BOLD); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub = text("YOUR PERSONAL VOICE ASSISTANT", 11, Color.LTGRAY); sub.setGravity(Gravity.CENTER); root.addView(sub);
        status = text("Ready • Tap the microphone and speak", 14, Color.rgb(125,220,255)); status.setGravity(Gravity.CENTER); status.setPadding(0,22,0,16); root.addView(status);
        Button mic = new Button(this); mic.setText("🎙  TALK TO SUMAN AI"); mic.setTextColor(Color.WHITE); mic.setTextSize(16); mic.setBackground(bg(Color.rgb(12,105,145),60)); root.addView(mic, new LinearLayout.LayoutParams(-1,58));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); conversation = text("Suman AI: Hello! I am your assistant. You can type or speak a command.\n\nTry: ‘What can you do?’ or ‘Open settings’.\n\nNote: This starter version runs basic phone commands. Online AI services will be connected in a later step.",15,Color.WHITE); conversation.setPadding(14,14,14,14); conversation.setBackground(bg(Color.rgb(13,31,49),20)); scroll.addView(conversation); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,0,1); sp.setMargins(0,18,0,16); root.addView(scroll,sp);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        input = new EditText(this); input.setSingleLine(true); input.setTextColor(Color.WHITE); input.setHintTextColor(Color.LTGRAY); input.setHint("Type a command..."); input.setPadding(14,0,14,0); input.setBackground(bg(Color.rgb(20,43,62),40)); row.addView(input,new LinearLayout.LayoutParams(0,54,1));
        Button send = new Button(this); send.setText("SEND"); send.setTextColor(Color.WHITE); send.setBackground(bg(Color.rgb(12,105,145),40)); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(95,54); bp.setMargins(8,0,0,0); row.addView(send,bp); root.addView(row);
        TextView footer = text("Private by design • Actions require your instruction",11,Color.LTGRAY); footer.setGravity(Gravity.CENTER); footer.setPadding(0,14,0,0); root.addView(footer);
        setContentView(root);
        mic.setOnClickListener(v -> startListening()); send.setOnClickListener(v -> { String s=input.getText().toString().trim(); if(!s.isEmpty()){ input.setText(""); handle(s); } });
    }
    private void addLine(String who, String message) { conversation.append("\n\n"+who+": "+message); }
    private void speak(String s) { if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"suman_reply"); }
    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.setText("Speech recognition is not available on this phone."); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO); return; }
        if(recognizer!=null) recognizer.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){status.setText("Listening…");} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){status.setText("Understanding…");}
            public void onError(int e){status.setText("Could not hear clearly. Tap and try again.");}
            public void onResults(Bundle b){ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()) handle(a.get(0)); status.setText("Ready");}
            public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle p){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault()); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"en-IN"); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false); recognizer.startListening(i);
    }
    private void handle(String raw) {
        addLine("You",raw); String q=raw.toLowerCase(Locale.ROOT).trim(); String answer;
        if(q.contains("what can you do")||q.equals("help")) answer="I can answer basic questions, speak replies, and open supported phone settings. More AI abilities will be added in later versions.";
        else if(q.contains("open settings")||q.contains("phone settings")) { answer="Opening Android settings."; addLine("Suman AI",answer); speak(answer); startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); return; }
        else if(q.contains("open camera")) { answer="I will open the camera."; addLine("Suman AI",answer); speak(answer); Intent i=new Intent("android.media.action.IMAGE_CAPTURE"); if(i.resolveActivity(getPackageManager())!=null) startActivity(i); else {answer="Camera app is not available.";addLine("Suman AI",answer);speak(answer);} return; }
        else if(q.contains("open whatsapp")) { Intent launch=getPackageManager().getLaunchIntentForPackage("com.whatsapp"); if(launch!=null){answer="Opening WhatsApp.";addLine("Suman AI",answer);speak(answer);startActivity(launch);return;} else answer="WhatsApp is not installed."; }
        else if(q.contains("hello")||q.contains("hi suman")) answer="Hello! I am ready. Tell me what you need.";
        else answer="I heard you say: '"+raw+"'. I do not have the connected AI brain yet, so I cannot safely perform that task. This starter version supports a few basic commands.";
        addLine("Suman AI",answer); speak(answer);
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==REQ_AUDIO&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)startListening();else status.setText("Microphone permission is needed for voice commands.");}
    @Override protected void onDestroy(){if(recognizer!=null)recognizer.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}
}
